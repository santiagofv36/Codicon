module.exports = {
    database: {
        connectionLimit: 10,
        host: 'localhost',
        user: 'c1532136_codicon',
        password: 'Aczonah123456',
        database: 'c1532136_codicon'
    }
};
/*
Usuario c1532136_codicon
Clave: Aczonah123456
Base de datos: c1532136_codicon
Servidor: localhost*/